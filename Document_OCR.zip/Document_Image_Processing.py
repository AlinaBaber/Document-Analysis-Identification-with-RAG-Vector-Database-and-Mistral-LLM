from PIL import Image
import pytesseract
import cv2
import numpy as np
from pdf2image import convert_from_path, convert_from_bytes
import fitz  # PyMuPDF
import os
import imutils as im
from skimage.filters import threshold_local

class DocumentImagePreprocessing:
    def __init__(self, pdf_documents_path):
        self.pdf_documents_path = pdf_documents_path

    def pdf_to_images(self, pdf_path, output_folder):
        # Ensure the output folder exists
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        # Open the PDF file
        pdf_document = fitz.open(pdf_path)

        # Get the total number of pages in the PDF
        total_pages = len(pdf_document)

        for page_no in range(total_pages):
            # Select the page
            page = pdf_document.load_page(page_no)

            # Convert the page to an image (PNG format)
            image = page.get_pixmap()

            # Save the image to the output folder
            image_filename = f"page_{page_no + 1}.png"  # Naming the images as page_1.png, page_2.png, etc.
            image_path = os.path.join(output_folder, image_filename)
            image.save(image_path)

        # Close the PDF document
        pdf_document.close()

    def process_multiple_pdfs(self, pdf_folder, output_folder):
        # List all files in the PDF folder
        pdf_files = [f for f in os.listdir(pdf_folder) if f.endswith('.pdf')]

        # Create the output folder if it doesn't exist
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        for pdf_file in pdf_files:
            pdf_path = os.path.join(pdf_folder, pdf_file)

            # Convert the PDF to an image using your pdf_to_image function
            page_no = 0  # Assuming page_no is fixed as 0 for this example, you can modify as needed
            image = self.pdf_to_image(pdf_path, page_no)

            # Save the image to the output folder with the same name as the PDF
            image_filename = os.path.splitext(pdf_file)[0] + '.png'
            image_path = os.path.join(output_folder, image_filename)
            cv2.imwrite(image_path, image)

    def pdf_to_image(self, pdf_path, page_no):
        # Ensure the output folder exists
        temp_folder = 'temp_images'
        if not os.path.exists(temp_folder):
            os.makedirs(temp_folder)

        # Open the PDF file
        pdf_document = fitz.open(pdf_path)

        # Get the total number of pages in the PDF
        total_pages = len(pdf_document)

        if page_no < 0 or page_no >= total_pages:
            raise ValueError("Invalid page number")

        # Select the page
        page = pdf_document.load_page(page_no)

        # Convert the page to an image (PNG format)
        image = page.get_pixmap()

        # Save the image to the temp folder
        image_path = os.path.join(temp_folder, f"temp_page_{page_no}.png")
        image.save(image_path)

        # Close the PDF document
        pdf_document.close()

        # Read the saved image using OpenCV
        image_cv = cv2.imread(image_path)

        # Clean up: Remove the temporary image
        os.remove(image_path)

        return image_cv

    def determine_score(self, arr, angle):
        data = im.rotate(arr, angle, reshape=False, order=0)
        histogram = np.sum(data, axis=1, dtype=float)
        score = np.sum((histogram[1:] - histogram[:-1]) ** 2, dtype=float)
        return histogram, score

    def correct_skew(self, image, delta=1, limit=5):
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        thresh = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
        scores = []
        angles = np.arange(-limit, limit + delta, delta)
        for angle in angles:
            histogram, score = self.determine_score(thresh, angle)
            scores.append(score)
        best_angle = angles[scores.index(max(scores))]
        h, w = image.shape
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, best_angle, 1.0)
        rotated = cv2.warpAffine(image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
        return best_angle, rotated
    def preprocess_image(img_blob):
        try:
            img_blob = np.array(img_blob)
            img_blob = cv2.cvtColor(img_blob, cv2.COLOR_BGR2GRAY)
            _, img_blob = cv2.threshold(img_blob, 127, 255, cv2.THRESH_BINARY_INV)
            return img_blob
        except:
            return None


    def contour_to_rect(self, contour):
        pts = contour.reshape(4, 2)
        rect = np.zeros((4, 2), dtype="float32")
        # top-left point has the smallest sum
        # bottom-right has the largest sum
        s = pts.sum(axis=1)
        rect[0] = pts[np.argmin(s)]
        rect[2] = pts[np.argmax(s)]
        # compute the difference between the points:
        # the top-right will have the minimum difference
        # the bottom-left will have the maximum difference
        diff = np.diff(pts, axis=1)
        rect[1] = pts[np.argmin(diff)]
        rect[3] = pts[np.argmax(diff)]
        return rect

    def wrap_perspective(self, img, rect):
        # unpack rectangle points: top left, top right, bottom right, bottom left
        (tl, tr, br, bl) = rect
        # compute the width of the new image
        widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
        widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
        # compute the height of the new image
        heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
        heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
        # take the maximum of the width and height values to reach
        # our final dimensions
        maxWidth = max(int(widthA), int(widthB))
        maxHeight = max(int(heightA), int(heightB))
        # destination points which will be used to map the screen to a "scanned" view
        dst = np.array([
            [0, 0],
            [maxWidth - 1, 0],
            [maxWidth - 1, maxHeight - 1],
            [0, maxHeight - 1]], dtype="float32")
        # calculate the perspective transform matrix
        M = cv2.getPerspectiveTransform(rect, dst)
        # warp the perspective to grab the screen
        return cv2.warpPerspective(img, M, (maxWidth, maxHeight))

    def document_image_rotation(self, image):
        _, rotated_image = self.correct_skew(image)
        return rotated_image

    def fourier_transform_image(self, image):
        # Compute phase, magnitude, or spectrum
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        fft = np.fft.fft2(gray)
        fshift = np.fft.fftshift(fft)

        fshift = np.ascontiguousarray(fshift)

        magnitude_spectrum = np.log(np.abs(fshift))
        magnitude_spectrum *= 255.0 / magnitude_spectrum.max()
        magnitude_spectrum = magnitude_spectrum.astype(np.uint8)
        return magnitude_spectrum

    def adaptive_thresholding_image(self, image, method_idx, block_size, c_constant):
        if method_idx == 1:
            image = cv2.adaptiveThreshold(
                image,
                255,
                cv2.ADAPTIVE_THRESH_MEAN_C,
                cv2.THRESH_BINARY,
                block_size,
                c_constant,
            )
        elif method_idx == 2:
            image = cv2.adaptiveThreshold(
                image,
                255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY,
                block_size,
                c_constant,
            )
        else:
            image = image

        image_h, image_w = image.shape
        return image, image_h, image_w

    def binary_thresholding_image(self, image, threshold, method_idx):
        if method_idx == 1:
            _, image = cv2.threshold(image, threshold, 255, cv2.THRESH_BINARY)
        elif method_idx == 2:
            _, image = cv2.threshold(image, threshold, 255, cv2.THRESH_BINARY_INV)
        elif method_idx == 3:
            _, image = cv2.threshold(image, threshold, 255, cv2.THRESH_TRUNC)
        elif method_idx == 4:
            _, image = cv2.threshold(image, threshold, 255, cv2.THRESH_TOZERO)
        elif method_idx == 5:
            _, image = cv2.threshold(image, threshold, 255, cv2.THRESH_TOZERO_INV)
        elif method_idx == 6:
            image = cv2.adaptiveThreshold(
                image, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2
            )
        elif method_idx == 7:
            image = cv2.adaptiveThreshold(
                image,
                255,
                cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY,
                11,
                2,
            )
        else:
            image = image

        image_h, image_w = image.shape
        return image, image_h, image_w

    def otsus_thresholding_image(self, image, method_idx):
        if method_idx == 0:
            ret, image = "-", image
        elif method_idx == 1:
            ret, image = cv2.threshold(
                image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
            )
        else:
            return

        image_h, image_w = image.shape
        return image, image_h, image_w

    def bw_scanner(self, image):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        T = threshold_local(gray, 21, offset=5, method="gaussian")
        return (gray > T).astype("uint8") * 255

    def document_image_enhancement(self, image_documents, technique, method_idx=None, block_size=None):
        # Implement image enhancement techniques
        if technique == "fft":
            image = self.fourier_transform_image(image_documents)
        elif technique == "adaptive_thresholding":
            image, _, _ = self.adaptive_thresholding_image(image_documents, method_idx, block_size, 2)
        elif technique == "binary_thresholding":
            image, _, _ = self.binary_thresholding_image(image_documents, 128, method_idx)
        return image

    def crop_and_preprocess_image(self,imgBlob, xmin, ymin, xmax, ymax):
        cropped_image = imgBlob[ymin:ymax+20, xmin+20:xmax+10]
        ymin2 = ((ymax-ymin) - 100) + ymin
        if ymin2 > ymax:
            ymin2 = ymin
        custom_image = imgBlob[ymin2:ymax+20, xmin+20:xmax+10]
        resized_image = cv2.resize(custom_image, None, fx=8, fy=8)
        gray_image = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)
        _, binary_image = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
        cleaned_image = cv2.medianBlur(binary_image, 9)
        _, black_and_white = cv2.threshold(cleaned_image, 127, 255, cv2.THRESH_BINARY_INV)
        return black_and_white
    def eob_preprocess_image(self,final_image):
        #final_image = np.array(final_image)
        #dh, dw, dimension = final_image.shape
        final_image = cv2.resize(np.array(final_image), None, fx=1.75, fy=1.75)#,interpolation = cv2.INTER_CUBIC)
        gray = cv2.cvtColor(np.array(final_image), cv2.COLOR_BGR2GRAY) if len(np.array(final_image).shape)==3 else np.array(final_image)
        _, final_image = cv2.threshold(gray,170, 255, cv2.THRESH_BINARY_INV)
        final_image = cv2.medianBlur(final_image, 7)
        final_image = cv2.blur(final_image,(3,3))
        return final_image

    def document_page_slicing(self, image_documents):
        # Implement page slicing
        pass

    def document_page_splitting(self, image_documents):
        # Implement page splitting
        pass

    def document_image_cropping(self, image_documents):
        # Implement image cropping
        pass
