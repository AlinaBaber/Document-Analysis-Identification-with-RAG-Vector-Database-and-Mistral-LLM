import heapq
import json
import re
import string
import pandas as pd
import nltk as nltk
import numpy as np
from keras.src.utils import pad_sequences
from matplotlib import pyplot as plt
from GraphicalDataHandling import GraphicalDataHandling
from Load_classification_Models import MLModels

class DocumentMLClassification:
    def __init__(self,model_pickle_file_path):
        #os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = google_credentials_path
        #self.client = vision.ImageAnnotatorClient()
        self.test=0
        # Create an instance of the MLModels class
        model_loader = MLModels(model_pickle_file_path)
        self.tokenizer,  self.classification_model = model_loader.load_classification_model()

    def predict_from_text(self,text):

        words = set(nltk.corpus.words.words())
        # add word to words set

        newStopWords = ['Subpoena', 'Quash', 'Ducus', 'Tecum']
        words.update(newStopWords)
        #words

        text = " ".join(w for w in nltk.wordpunct_tokenize(text)              if w.lower() in words or not w.isalpha())
        seq = self.tokenizer.texts_to_sequences([text])
        #seq = tokenizer.texts_to_sequences(new_file)

        padded = pad_sequences(seq, maxlen=2150) # 4300
        pred = self.classification_model.predict(padded)
        return pred

    def process_predictions(self,preds, labels, pageNum):
        # Assuming preds is a list of prediction values
        [current_preds] = preds
        current_preds = np.array(current_preds)
        current_preds = heapq.nlargest(3, enumerate(current_preds), key=lambda x: x[1])

        percentage1 = current_preds[0][1] * 100
        predicted_label1 = str(labels[int(current_preds[0][0])])
        predicted_per1 = round(percentage1, 3)

        print(predicted_label1, " Predicted Percentage : ", "{:.2f}".format(round(percentage1, 3)), "%")

        percentage2 = current_preds[1][1] * 100
        predicted_label2 = str(labels[int(current_preds[1][0])])
        predicted_per2 = round(percentage2, 3)

        print(predicted_label2, " Predicted Percentage : ", "{:.2f}".format(round(percentage2, 3)), "%")

        document_type = predicted_label1

        page_new = int(pageNum) + 1

        model_predicted_doc = str(document_type)
        model_predicted_per = str(predicted_per1)

        return model_predicted_doc, model_predicted_per, page_new

    def read_dict_from_json(self,json_file_name):
        """
        Read a dictionary from a JSON file.

        Args:
            json_file_name (str): The name of the JSON file to read.

        Returns:
            dict or None: The dictionary read from the JSON file, or None if an error occurs.
        """
        try:
            with open(json_file_name, "r") as json_file:
                data_dict = json.load(json_file)
            print(f"Dictionary read from {json_file_name}")
            return data_dict
        except Exception as e:
            print(f"Error reading dictionary from {json_file_name}: {str(e)}")
            return None

    def scoredocuments(self,doctext,json_path):
        # Convert all strings to lowercase
        text = doctext.lower()

        # Remove numbers
        text = re.sub(r'\d+', '', text)

        # Remove punctuation
        text = text.translate(str.maketrans('', '', string.punctuation))

        # Load terms from the JSON file
        with open(json_path, 'r') as json_file:
            terms = json.load(json_file)

        # Initialize score counters for each area
        scores = {area: 0 for area in terms.keys()}

        # Obtain the scores for each area
        for area, area_terms in terms.items():
            for word in area_terms:
                if word in text:
                    scores[area] += 1

        # Create a data frame with the scores summary
        summary = pd.DataFrame(scores.values(), index=scores.keys(), columns=['score']).sort_values(by='score', ascending=False)
        print(summary)

        return summary['score']


    def graphicscore( self ,text):
        #gd=GraphicalDataHandling()
        json_path = r"C:\Users\alina.babar\PycharmProjects\RLDocAgent\Jsons\documenttypes.json"  # Replace with the actual path to your JSON file
        import os
        import json

        # Specify the path to the directory containing the JSON files
        directory = r"C:\Users\alina.babar\PycharmProjects\RLDocAgent\Jsons"
        gd=GraphicalDataHandling(directory)
        maindocumenttype,maindocumentkeywords,subdocumenttype =gd.transformdictionary()
        #print(maindocumenttype)
        #print(subdocumenttype)
        graph=gd.docgraph(maindocumenttype,maindocumentkeywords,subdocumenttype)
        # Find all nodes that contain a given keyword
        #text = "a copy of the bill along with  please also be certain that consider this billing for payment"
        documenttype,summarymaindocs ,summarysubdocs =gd.graphdocscore(text,graph,maindocumentkeywords,subdocumenttype)
        return documenttype,summarymaindocs ,summarysubdocs

dc=DocumentMLClassification(r"C:/Users/alina.babar/PycharmProjects/RLDocAgent/Models")
# Example usage
text = "a copy of the bill along with  please also be certain that consider this billing for payment"
json_path = r"C:\Users\alina.babar\PycharmProjects\RLDocAgent\Jsons\documenttypes.json"  # Replace with the actual path to your JSON file

scores = dc.scoredocuments(text, json_path)
print(scores)
documenttype,summarymaindocs ,summarysubdocs=dc.graphicscore(text)
