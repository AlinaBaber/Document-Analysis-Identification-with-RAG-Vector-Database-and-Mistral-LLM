import re
import nltk
from nltk.tokenize import WordPunctTokenizer
from nltk.stem import WordNetLemmatizer
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import words

# Download NLTK data if not already downloaded
nltk.download('punkt')
nltk.download('words')

class DocumentTextProcessing:
    def __init__(self):
        #os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = google_credentials_path
        #self.client = vision.ImageAnnotatorClient()
        self.text =0
        # Initialize necessary resources
        nltk.download('words')
        self.wordnet_lemmatizer = WordNetLemmatizer()
        # Define a list of stop words
        self.stop_words = set(nltk.corpus.stopwords.words('english'))
        nltk.download('stopwords')
        nltk.download('wordnet')
        nltk.download('words')
        self.stop = stopwords.words('english')
        for punct in punctuation:
            self.stop.append(punct)

    def change_abbreviations(text):
        # Define a dictionary of abbreviations and their expansions
        abbreviations = {
            " AME ": " agreed medical evaluation ",
            "A.M.E": "agreed medical evaluation",
            "A.M.E.": "agreed medical evaluation",
            " DFR ": " doctor first report ",
            " dfr ": " doctor first report ",
            " P&S ": " permanent and stationary ",
            " PS ": " permanent and stationary ",
            # Add more abbreviations and expansions as needed
        }

        # Replace abbreviations with their expansions
        for abbreviation, expansion in abbreviations.items():
            text = text.replace(abbreviation, expansion)

        return text

    def replace_words(text):
        # Define a dictionary of word replacements
        replacements = {
            "compronise": "compromise",
            "prgof": "proof",
            "compromiseand": "compromise",
            "rogressreport": "progress report",
            "wojkers": "workers",
            "cnter": "center",
            "coter": "center",
            " arimary ": " primary ",
            # Add more word replacements as needed
        }

        # Replace words in the text
        for old_word, new_word in replacements.items():
            text = text.replace(old_word, new_word)

        return text

    def delete_extra_words(text):
        # Define a list of words to delete
        words_to_delete = [
            "date",
            "number",
            "address",
            "phone",
            "nuys",
            "pobox",
            "box",
            "street",
            "address",
            "birth",
            "pdffactory",
            "division",
            "first",
            "last",
            "city",
            "please",
            "page",
            "compensation",
            "appeal",
            "board",
            "code",
            "kent",
            "right",
            "total",
            "leave",
            "gold",
            "star",
            "eagle",
            "maria",
            "august",
            "pain",
            "hour",
            "signature",
            "physician",
            "administrator",
            "roberta",
            "hamlinpsychecenter",
            "hamlin psyche center",
            "hamlin",
            "treatment coordinator",
            "blvd",
            "medical director",
            "long beach",
            "section 4600",
            "physicirn",
            "teports",
            "lc 4600",
            "rx:",
            "dx:",
            "dx ",
            "national bank",
            "batch number",
            "processing date",
            "transaction no",
            "sequence no",
            "subseqno",
            "imageseq",
            "worksource",
            "front image",
            "agreiment",
            "agresment",
            "ilens filed",
            "lens filed",
            "oases",
            "agreoment",
            "represontative",
            "wien/balances",
            "crder",
            "diemissed",
            "balanges",
            "above-entitied",
            "this/thase",
            "1s",
            "readrd",
            "phyveician",
            "sicnyotire",
            "rennnnen",
            "peennnnnes",
            "atty",
            "shoulder r l",
            "elbow r l",
            "wrist r l",
            "handr l",
            "hand r l",
            "hip r l",
            "kneer l",
            "knee r l",
            "ankle r l",
            "feetr l",
            "feet r l",
            "c-sp",
            "t-sp",
            "l-sp",
            "pnbefore tx",
            "pn before tx",
            "pnaftertx",
            "pn after tx",
            "tx area",
            "tx render",
            "pwaftertx",
            "pnbefore",
            "attornys",
            "atiomay",
            "béen",
            "rejection of dor",
            "dor for msc",
            "bodypat",
            "bodypet",
            "phystcian",
            "rignt",
            "olfice",
            "ollice",
            "x-rays",
            " mri(s)",
            " ct(s)",
            " mri ",
            " ct ",
            "p mumary",
            "chent",
            "dioase",
            "jorward",
            "ape lication",
            "treat ting",
            " rimary",
            "picase",
            "since vouts",
            "omen sation",
            "visteted",
            "previsians",
            "labor cede",
            "ar conepted",
            "revund",
            "oreference",
            "disccunt",
            "jnaucement",
            "undershsned",
            "calfornia",
            "wristr",
            "handr",
            "jupper extremities",
            "silateral",
            "jacupuncture",
            "compr mise",
            "cosursmise",
            "ceampromizs",
            "atiorney",
            "allewed",
            "compr®mise",
            "physicjan",
            "§ 4600",
            " 4600,",
            "noiige of ",
            "code sec.",
            "attormnmey",
            "attomey",
            "applicdnt",
            "approving c&r",
            "og thesack",
            "watermari",
            "gheck",
            "cashier's",
            "phape:",
            "betation",
            "petytion",
            "subsyifution",
            # Add more words to delete as needed
        ]

        # Delete specified words from the text
        for word in words_to_delete:
            text = text.replace(word, " ")

        # Remove extra spaces
        text = re.sub(r'\s+', ' ', text)

        return text

    def filter_text(text, stop_words):
        # Tokenize the text and apply filtering and lemmatization
        word_tokens = WordPunctTokenizer().tokenize(text.lower())
        filtered_text = [regex.sub(u'\p{^Latin}', u'', w) for w in word_tokens if w.isalpha() and len(w) > 3]
        filtered_text = [wordnet_lemmatizer.lemmatize(w, pos="v") for w in filtered_text if not w in stop_words]

        return " ".join(filtered_text)

    def get_only_english_words(text):
        # Filter out non-English words from the text
        words = set(nltk.corpus.words.words())
        text = " ".join(w for w in nltk.wordpunct_tokenize(text) if w.lower() in words or not w.isalpha())

        return text

    def make_wordcloud(words,title):
        cloud = WordCloud(width=1920, height=1080,max_font_size=200, max_words=300, background_color="white").generate(words)
        plt.figure(figsize=(20,20))
        plt.imshow(cloud, interpolation="gaussian")
        plt.axis("off")
        plt.title(title, fontsize=60)
        plt.show()

    def cleaning_text_eob(text):
        # Define a dictionary for replacements
        replacements = {
            ',': '.', '$': '', '|': '', '-': ' ', '[': '', ']': '', '}': '', '{': '',
            '__': '', '_': '', '\'': '', '"': '', '°': '', '=': '', '@': '&', '£': 'E',
            '€': 'E', '«': '', ':': '', ';': '', '»': '', '¢': '', '#': '', '~': '', '..': '',
            '“': '', '″': '', '(s)': 's', '”': '', '‘': '', '¢': ''
        }

        # Apply replacements using a loop
        for old, new in replacements.items():
            text = text.replace(old, new)

        # Convert to lowercase
        text = text.lower()

        # Remove extra spaces and newline characters
        text = re.sub(' +', ' ', text)
        text = ' '.join(text.split('\n'))

        return text

    def change_abbreviations(text):
        # Define a dictionary of abbreviations and their expanded forms
        abbreviations = {
            " AME ": " agreed medical evaluation ",
            "A.M.E": "agreed medical evaluation",
            "A.M.E.": "agreed medical evaluation",
            " DFR ": " doctor first report ",
            " dfr ": " doctor first report ",
            " P&S ": " permanent and stationary ",
            " PS ": " permanent and stationary ",
            " PQME ": " panel qualified medical evaluation ",
            " pqme ": " panel qualified medical evaluation ",
            " NOR ": " notice of representation ",
            " C&R ": " COMPROMISE AND RELEASE ",
            " RFA ": " REQUEST FOR AUTHORIZATION ",
            " UR ": " utilization review ",
            " DOR ": " DECLARATION OF READINESS ",
            " NOH ": " notice of hearing ",
            " L.C ": "labor code",
            " 4600 ": " four six zero zero ",
            " EAMS ": " Electronic Adjudication Management System ",
            " ERQ ": " Employer Responsibilities Questionnaire ",
            "PR-2": "second",
            "PR2": "second",
            "PR-4": "four",
            "PR4": "four",
            "Srv ": "service ",
            " Qty ": " quantity ",
            " Adj ": " adjustment ",
            " Pmt ": " payment ",
            " Inv Status ": " invoice status ",
            "caseclosed": "case closed",
            " nsurance ": " insurance ",
            " cffice ": " office ",
            " needsto ": " need to ",
        }

        # Replace abbreviations with their expanded forms
        for abbreviation, expanded_form in abbreviations.items():
            text = text.replace(abbreviation, expanded_form)

        return text

    def replace_words(text):
        # Define a dictionary of word replacements
        word_replacements = {
            "compronise": "compromise",
            "prgof": "proof",
            "compromiseand": "compromise",
            "rogressreport": "progress report",
            "wojkers": "workers",
            "cnter": "center",
            "coter": "center",
            " arimary ": " primary ",
        }

        # Replace words with their correct forms
        for word, replacement in word_replacements.items():
            text = text.replace(word, replacement)

        return text

    def delete_extra_words(delete_extra_words_text):
        # Define a dictionary of word replacements
        word_replacements = {
            "date": " ",
            "number": " ",
            "address": " ",
            "phone": " ",
            "box": " ",
            "street": " ",
            "address": " ",
            "birth": " ",
            "division": " ",
            "first": " ",
            "last": " ",
            "city": " ",
            "please": " ",
            "page": " ",
            "compensation": " ",
            "appeal": " ",
            "board": " ",
            "code": " ",
            "right": " ",
            "leave": " ",
            "gold": " ",
            "star": " ",
            "eagle": " ",
            "maria": " ",
            "august": " ",
            "pain": " ",
            "hour": " ",
            "signature": " ",
            "physician": " ",
            "administrator": " ",
            "roberta": " ",
            "hamlinpsychecenter": " ",
            "hamlin psyche center": " ",
            "hamlin": " ",
            "treatment coordinator": " ",
            "blvd": " ",
            "medical director": " ",
            "long beach": " ",
            "compromiseand": "compromise",
            "compronise": "compromise",
            "compronise": "compromise",
            "rogressreport": "progress report",
            "wojkers": "workers",
            "cnter": "center",
            "coter": "center",
            "arimary": "parimary",
            "section 4600": "section four six zero zero",
            "physicirn": "physician",
            "teports": "report",
            "lc 4600": "labor code four six zero zero",
            "rx:": "medical prescription",
            "dx:": "diagnosis prescription",
            "dx": "diagnosis prescription",
            "national bank": "",
            "batch number": "",
            "processing date": "",
            "transaction no": "",
            "sequence no": "",
            "subseqno": "",
            "imageseq": "",
            "worksource": "",
            "front image": "",
            "agreiment": "agreement",
            "agresment": "agreement",
            "ilens filed": "lien filed",
            "lens filed": "lien filed",
            "oases": "cases",
            "agreoment": "agreement",
            "represontative": "representative",
            "wien/balances": "lien balance",
            "crder": "order",
            "diemissed": "dismiss",
            "balanges": "balance",
            "above-entitied": "above-entitled",
            "this/thase": "this/these",
            "1s": "is",
            "readrd": "record",
            "phyveician": "physician",
            "sicnyotire": "signature",
            "rennnnen": "",
            "peennnnnes": "",
            "atty": "attorney",
            "shoulder r l": "shoulder right left",
            "elbow r l": "elbow right left",
            "wrist r l": "wrist right left",
            "handr l": "hand right left",
            "hand r l": "hand right left",
            "hip r l": "hip right left",
            "kneer l": "knee right left",
            "knee r l": "knee right left",
            "ankle r l": "ankle right left",
            "feetr l": "feet right left",
            "feet r l": "feet right left",
            "c-sp": "cavum septi pellucidi",
            "t-sp": "total soluble protein",
            "l-sp": "left sacroposterior position",
            "pnbefore tx": "patient before treatment therapy",
            "pn before tx": "patient before treatment therapy",
            "pnaftertx": "patient after treatment therapy",
            "pn after tx": "patient after treatment therapy",
            "tx area": "treatment therapy area",
            "tx render": "treatment therapy render",
            "pwaftertx": "patient after treatment therapy",
            "pnbefore": "patient before",
            "attornys": "attorney",
            "atiomay": "attorney",
            "béen": "been",
            "rejection of dor": "rejection of declaration of readiness",
            "dor for msc": "declaration of readiness for mendatory settlement conference",
            "bodypat": "body part",
            "bodypet": "body part",
            "phystcian": "physician",
            "rignt": "right",
            "olfice": "office",
            "ollice": "office",
            "x-rays": "electromagnetic waves",
            "mri(s)": "magnetic resonance imaging",
            "ct(s)": "computed tomography",
            "mri": "magnetic resonance imaging",
            "ct": "computed tomography",
            "p mumary": "primary",
            "chent": "client",
            "dioase": "please",
            "jorward": "forward",
            "ape lication": "application",
            "treat ting": "treating",
            "rimary": "primary",
            "picase": "please",
            "since vouts": "sincerely yours",
            "omen sation": "compensation",
            "visteted": "violated",
            "previsians": "provisions",
            "labor cede": "labor code",
            "ar conepted": "or accepted",
            "revund": "refund",
            "oreference": "preference",
            "disccunt": "discount",
            "jnaucement": "inducement",
            "undershsned": "undersigned",
            "calfornia": "california",
            "wristr": "wrist right",
            "handr": "hand right",
            "jupper extremities": "upper extremities",
            "silateral": "bilateral",
            "jacupuncture": "acupuncture",
            "compr mise": "compromise",
            "cosursmise": "compromise",
            "ceampromizs": "compromise",
            "atiorney": "attorney",
            "allewed": "allowed",
            "compr®mise": "compromise",
            "physicjan": "physician",
            "§ 4600": "four six zero zero",
            " 4600,": " four six zero zero ",
            "noiige of ": "notice of ",
            "code sec.": "code section",
            "attormnmey": "attorney",
            "attomey": "attorney",
            "applicdnt": "applicant",
            "approving c&r": "approving compromise and release",
            "og thesack": "on the back",
            "watermari": "watermark",
            "gheck": "check",
            "cashier's": "cashier",
            "phape:": "phone",
            "betation": "petition",
            "petytion": "petition",
            "subsyifution": "substitution",
        }

        # Replace words from the dictionary
        for word, replacement in word_replacements.items():
            delete_extra_words_text = delete_extra_words_text.replace(word, replacement)

        # Remove extra spaces
        delete_extra_words_text = ' '.join(delete_extra_words_text.split())

        return delete_extra_words_text


    def filter_text(text, stop_words):


        word_tokens = WordPunctTokenizer().tokenize(text.lower())
        filtered_text = [regex.sub(u'\p{^Latin}', u'', w) for w in word_tokens if w.isalpha() and len(w) > 3]
        filtered_text = [wordnet_lemmatizer.lemmatize(w, pos="v") for w in filtered_text if not w in stop_words]
        return " ".join(filtered_text)

    def get_only_english_words(text):
        words = set(nltk.corpus.words.words())
        text = " ".join(w for w in nltk.wordpunct_tokenize(text)              if w.lower() in words or not w.isalpha())
    #     print("Final Text :" + str(text))
        return text



