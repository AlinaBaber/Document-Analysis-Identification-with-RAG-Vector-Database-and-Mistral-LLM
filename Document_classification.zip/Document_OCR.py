import os
import re
import datetime
import numpy as np
import cv2
import dateutil.parser as dparser
import pytesseract
import pdf2image
import glob
from google.cloud import vision
from google.cloud.vision_v1 import types
import re

class DocumentOCR:
    def __init__(self,google_credentials_path=None):
        #os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = google_credentials_path
        #self.client = vision.ImageAnnotatorClient()
        self.a=0

    def detect_text_with_tesseract(self, image_path):
        try:
            # Load the image using OpenCV
            image = cv2.imread(image_path)

            # Perform OCR using Tesseract
            text = pytesseract.image_to_string(image)

            return text
        except Exception as e:
            print("Error during Tesseract OCR:", str(e))
            return ""
        # Google API convert image
    def perform_ocr(self, image_path, ocr_method):
        if ocr_method == "google_vision":
            return self.detect_text(image_path)  # You can choose the appropriate Google Vision method
        elif ocr_method == "tesseract":
            return self.detect_text_with_tesseract(image_path)
        else:
            return "Unsupported OCR method"
    """
    def detect_text(self,path):
        image = types.Image(content=cv2.imencode('.jpg', path)[1].tostring())
        response = self.client.text_detection(image=image)
        texts = response.text_annotations
        string = ''
        for text in texts:
            string+=' ' + text.description
        return string

    def detect_text2(self,path):
        image = types.Image(content=cv2.imencode('.jpg', path)[1].tostring())

        response = self.client.document_text_detection(image=image)
        items = []
        lines = {}

        for text in response.text_annotations[1:]:
            top_x_axis = text.bounding_poly.vertices[0].x
            top_y_axis = text.bounding_poly.vertices[0].y
            bottom_y_axis = text.bounding_poly.vertices[3].y

            if top_y_axis not in lines:
                lines[top_y_axis] = [(top_y_axis, bottom_y_axis), []]

            for s_top_y_axis, s_item in lines.items():
                if top_y_axis < s_item[0][1]:
                    lines[s_top_y_axis][1].append((top_x_axis, text.description))
                    break

        text = ""

        for _, item in lines.items():
            if item[1]:
                words = sorted(item[1], key=lambda t: t[0])
                items.append((item[0], ' '.join([word for _, word in words]), words))
                text = text + ' '.join([word for _, word in words])
                text = text + "\n"

        return text

    def google_vision_detection(self,img_blob, loop_date_regex, loop_doctor_regex):
        local_doctor_name = ""
        local_name_date = ""

        try:
            # Google Vision
            image = types.Image(content=cv2.imencode('.jpg', img_blob)[1].tostring())
            response = self.client.text_detection(image=image)
            texts = response.text_annotations
            string = ''
            for text in texts:
                string += ' ' + text.description
            return string
        except Exception as e:
            print("Message: ", str(e))

        return local_doctor_name, local_name_date
    """

